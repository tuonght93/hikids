<div class="form-group primary-form-group" id="form">
<div style="display: none;">
<input type="checkbox" name="form" value="1" /> Bạn có muốn chuyển hàng nhanh (<a style="text-decoration: underline;" href="{{ url('/page/chinh-sach-giao-hang') }}">xem chi tiết</a>)
</div>
</div>