<?php

return [
  'all'           => 'All',
  'new'           => 'New',
  'search'        => 'Search'
];
