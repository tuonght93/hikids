<?php

return [
  'home'            => 'Home',
  'user'            => 'User',
  'dashboard'       => 'Dashboard',
  'event'           => 'Event',

];
