<?php

return [
  'logout' => 'Logout',
  'add_new' => 'Add new',
];
