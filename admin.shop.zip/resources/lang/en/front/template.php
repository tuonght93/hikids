<?php

return [
  'introduction'         => 'Introduction',
  'diagnostics'          => 'Diagnostics',
  'microscopy'           => 'Microscopy',
  'rdt'                  => 'Rdt',
  'summary'              => 'Summary',

  'prev'                 => 'Prev',
  'next'                 => 'next',

  




];
