<?php

return [
  'introduction'         => 'Giới thiệu',
  'diagnostics'          => 'Chẩn đoán',
  'microscopy'           => 'Điểm KHV',
  'rdt'                  => 'Test nhanh',
  'summary'              => 'Tổng kết',

  'prev'                 => 'Trở lại',
  'next'                 => 'Tiếp tục',

];
