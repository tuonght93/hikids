<?php

return [
  'logout' => 'Thoát',
  'add_new' => 'Thêm mới',
];
