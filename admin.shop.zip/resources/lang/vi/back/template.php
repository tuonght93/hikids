<?php

return [
  'home'            => 'Trang chủ',
  'user'            => 'Người dùng',
  'dashboard'       => 'Thống kê',
  'event'           => 'Sư kiện',

];
