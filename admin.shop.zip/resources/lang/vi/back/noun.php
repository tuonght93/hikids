<?php

return [
  'all' => 'Tất cả',
  'new' => 'Mới'
];
