<?php use Illuminate\Support\Str as Str; 
    use Illuminate\Support\Facades\Session as Session;
 ?>

<?php $__env->startSection('title'); ?>
    <?php if(empty($seo['title'])): ?>
        <title>Trang chủ | Hikids</title>
    <?php else: ?>
        <title><?php echo e($seo['title']); ?></title>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<?php echo $__env->make('user/inc/slide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
		<!-- MAIN-CONTENT-SECTION START -->
		<section class="main-content-section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="row">
							<?php if($productsellings->count() > 0): ?>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="new-product-area">
									<div class="left-title-area">
										<h2 class="left-title">Quần áo trẻ em bán chạy</h2>
									</div>						
									<div class="row">
										<div class="col-xs-12">
											<div class="row">
												<!-- HOME2-NEW-PRO-CAROUSEL START -->
												<!-- <div class="home2-new-pro-carousel"> -->
													<!-- NEW-PRODUCT SINGLE ITEM START -->
													<?php foreach($productsellings as $item): ?>
													<div class="col-md-3">
													<div class="item">
														<div class="new-product">
															<div class="single-product-item">
																<div class="product-image zoom-img">
																	<a href="<?php echo e(url('/product/'.$item->slug)); ?>"><img class="zoom-img" src="<?php echo e(config('image.image_url').'/products/'.$item->image_url().'_400x300.png'); ?>" alt="<?php echo e($item->name); ?>" /></a>
																	<span class="new-mark-box">new</span>
																</div>
																<div class="product-info ty-grid-list__item-name">
																	<h3><a href="<?php echo e(url('/product/'.$item->slug)); ?>" class="product-title" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a></h3>
																	<div class="price-box ty-grid-list__price">
																		<span class="price"><?php echo e(number_format($item->price,0,",",".")); ?>  đ</span>
																		<?php if(!empty($item->old_price)): ?>
																		<span class="old-price"><?php echo e(number_format($item->old_price,0,",",".")); ?> đ</span>
																		<?php endif; ?>
																	</div>
																</div>
															</div>
														</div>
													</div>
													</div>
													<?php endforeach; ?>
													<!-- NEW-PRODUCT SINGLE ITEM END -->
												<!-- </div> -->
												<!-- HOME2-NEW-PRO-CAROUSEL END -->
											</div>
										</div>
									</div>
								</div>										
							</div>
							<?php endif; ?>
							<?php if($categories): ?>
							<?php
								$category = $categories::where('parent_id', '=', '')->get();
							?>
							<?php foreach($category as $cate): ?>
							<?php
								$products = $cate->products()->take(8)->get();
							?>
							<?php if(count($products) > 0): ?>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="new-product-area">
									<div class="left-title-area">
										<h2 class="left-title"><a href="<?php echo e(url('/category/'.$cate->slug)); ?>"><?php echo e($cate->name); ?></a></h2>
										<?php
											$category2 = $categories::where('parent_id', '=', $cate->id)->get();
										?>
										<?php if($category2->count() > 0): ?>
										<div class="ty-mainbox-submenu">
											<ul>
												<?php foreach($category2 as $cate2): ?>
												<li><a href="<?php echo e(url('/category/'.$cate->slug.'/'.$cate2->slug)); ?>" > <?php echo e($cate2->name); ?></a></li>
												<?php endforeach; ?>
											</ul>
										</div>
										<?php endif; ?>
									</div>
								</div>					
									<div class="row">
										<div class="col-xs-12">
											<div class="row">
												<!-- HOME2-NEW-PRO-CAROUSEL START -->
												<!-- <div class="home2-new-pro-carousel"> -->
													<!-- NEW-PRODUCT SINGLE ITEM START -->
													<?php foreach($products as $item): ?>
													<div class="col-md-3">
													<div class="item">
														<div class="new-product">
															<div class="single-product-item">
																<div class="product-image zoom-img">
																	<a href="<?php echo e(url('/product/'.$item->slug)); ?>"><img class="zoom-img" src="<?php echo e(config('image.image_url').'/products/'.$item->image_url().'_400x300.png'); ?>" alt="<?php echo e($item->name); ?>" /></a>
																	<span class="new-mark-box">new</span>
																</div>
																<div class="product-info ty-grid-list__item-name">
																	<h3><a href="<?php echo e(url('/product/'.$item->slug)); ?>" class="product-title" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a></h3>
																	<div class="price-box ty-grid-list__price">
																		<span class="price"><?php echo e(number_format($item->price,0,",",".")); ?>  đ</span>
																		<?php if(!empty($item->old_price)): ?>
																		<span class="old-price"><?php echo e(number_format($item->old_price,0,",",".")); ?> đ</span>
																		<?php endif; ?>
																	</div>
																</div>
															</div>
														</div>
													</div>
													</div>
													<?php endforeach; ?>
													<!-- NEW-PRODUCT SINGLE ITEM END -->
												<!-- </div> -->
												<!-- HOME2-NEW-PRO-CAROUSEL END -->
											</div>
										</div>
									</div>
								</div>	
							<?php endif; ?>
							<?php endforeach; ?>
							<?php endif; ?>									
							</div>
						</div>	
					</div>	
				</div>
		</section>
		<!-- MAIN-CONTENT-SECTION END -->

		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>