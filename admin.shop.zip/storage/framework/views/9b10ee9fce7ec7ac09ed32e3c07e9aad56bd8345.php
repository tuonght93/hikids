<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2><?php echo e($title); ?></h2>

		<div>
			<?php echo $intro; ?>.<br/> <br />
			<?php echo link_to($link, $link); ?><br/> <br />
			<?php echo $expire; ?>.
			<br/><br/>
			<h4>Thư được gửi từ: Omanage.techup.vn</h4>
		</div>
	</body>
</html>