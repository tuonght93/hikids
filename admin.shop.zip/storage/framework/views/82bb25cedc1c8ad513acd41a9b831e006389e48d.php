<?php use Illuminate\Support\Str as Str; 
    use Illuminate\Support\Facades\Session as Session;
 ?>

<?php $__env->startSection('title'); ?>
    <?php if(empty($seo['title'])): ?>
        <title>Sản phẩm | Happy Skin</title>
    <?php else: ?>
        <title><?php echo e($seo['title']); ?></title>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<!-- MAIN-CONTENT-SECTION START -->
<section class="main-content-section">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<!-- BSTORE-BREADCRUMB START -->
				<div class="bstore-breadcrumb">
					<div style="float: left;" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
						<a href="<?php echo e(url('/')); ?>" itemprop="url">Trang chủ</a>
					</div>
					<div style="float: left;" itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
						<span><i class="fa fa-caret-right"></i></span>
						<span itemprop="title"><?php echo e($product->name); ?></span>
					</div>
				</div>
				<!-- BSTORE-BREADCRUMB END -->
			</div>
		</div>	
		<br/>			
		<div class="row">
			<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
				<!-- SINGLE-PRODUCT-DESCRIPTION START -->
				<form action="<?php echo e(url('/cart')); ?>" method="post">
				<div class="row">

					<div class="col-lg-5 col-md-5 col-sm-4 col-xs-12">
						<input type="hidden" name="_token" id="token" value="<?php echo csrf_token(); ?>">
						<input type="hidden" name="product_id" id="product_id" value="<?php echo e($product->id); ?>">
						<div class="single-product-view">
							  <!-- Tab panes -->
							<div class="tab-content">
								<div class="tab-pane active" id="<?php echo e($product->id); ?>">
									<div class="single-product-image">
										<img src="<?php echo e(config('image.image_url').'/products/'.$product->image_url().'_800x600.png'); ?>" alt="single-product-image" />
										<a class="new-mark-box">new</a>
										<a class="fancybox" href="<?php echo e(config('image.image_url').'/products/'.$product->image_url().'_800x600.png'); ?>" data-fancybox-group="gallery"><span class="btn large-btn">View larger <i class="fa fa-search-plus"></i></span></a>
									</div>	
								</div>
								<?php if($productphotos): ?>
								<?php foreach( $productphotos as $productphoto): ?>
								<div class="tab-pane" id="<?php echo e($productphoto->id); ?>">
									<div class="single-product-image">
										<img src="<?php echo e(config('image.image_url').'/products/'.$productphoto->image_url().'_800x600.png'); ?>" alt="single-product-image" />
										<a class="new-mark-box" href="#">new</a>
										<a class="fancybox" href="<?php echo e(config('image.image_url').'/products/'.$productphoto->image_url().'_800x600.png'); ?>" data-fancybox-group="gallery"><span class="btn large-btn">View larger <i class="fa fa-search-plus"></i></span></a>
									</div>	
								</div>
								<?php endforeach; ?>
								<?php endif; ?>
							</div>										
						</div>
						<div class="select-product">
							<!-- Nav tabs -->
							<ul class="nav nav-tabs select-product-tab bxslider">
								<li class="active">
									<a href="#<?php echo e($product->id); ?>" data-toggle="tab"><img src="<?php echo e(config('image.image_url').'/products/'.$product->image_url().'_100x100.png'); ?>" alt="pro-thumbnail" /></a>
								</li>
								<?php if($productphotos): ?>
								<?php foreach( $productphotos as $productphoto): ?>
								<li>
									<a href="#<?php echo e($productphoto->id); ?>" data-toggle="tab"><img src="<?php echo e(config('image.image_url').'/products/'.$productphoto->image_url().'_100x100.png'); ?>" alt="pro-thumbnail" /></a>
								</li>
								<?php endforeach; ?>
								<?php endif; ?>
							</ul>										
						</div>
					</div>
					<div class="col-lg-7 col-md-7 col-sm-8 col-xs-12">
						<div class="single-product-descirption">
							<h1><?php echo e($product->name); ?></h1><br/><br/>
							<div class="single-product-price">
								<h2><?php echo e(number_format($product->price,0,",",".")); ?>  đ</h2>
							</div>
							<?php if($product->introduce): ?>
							<div class="single-product-desc">
								<p><?php echo e($product->introduce); ?></p>
							</div>
							<?php endif; ?>
							<?php if(!empty($productdetails)): ?>
			                <?php
			                  $productcolor = array();
			                  $productsize = array();
			                  $qty = array();
			                  foreach ($productdetails as $productdetail) {
			                    $productcolors[] = $productdetail->color_id;
			                    $productsizes[] = $productdetail->color_id.'-'.$productdetail->size_id;
			                    $qty[] = $productdetail->qty;
			                    $listtitles[] = $productdetail->color->title;
			                  }
			                  $colors = array_unique($productcolors);
			                  $titles = array_unique($listtitles);
			                  $details = array_combine($colors,$titles);
			                ?>
                			<?php endif; ?>
							<div class="single-product-size">
								<p class="small-title">Màu sắc </p> 
								<select name="product_color" id="product_color">
								<?php foreach( $details as $colors => $titles): ?>
									<option value="<?php echo e($colors); ?>"><?php echo e($titles); ?></option>
								<?php endforeach; ?>
								</select>
							</div>
							<?php
								$colorfirst = $productcolors[0];
								$sizes = $lists->where('product_id', '=', $product->id)->where('color_id', '=', $colorfirst)->get();
							?>
							<div class="single-product-size">
								<p class="small-title">Kích cỡ </p> 
								<select name="product_size" id="product_size">
									<?php foreach($sizes as $size): ?>
									<option value="<?php echo e($size->size_id); ?>"><?php echo e($size->size->title); ?></option>
									<?php endforeach; ?>
								</select>
							</div>
							<br/>
							<div class="single-product-add-cart">
								<button class="add-cart-text" type="submit" name="btncart" title="Add to cart">Mua ngay</button>
							</div>
						</div>
					</div>
				</div>
				</form>
				<!-- SINGLE-PRODUCT-DESCRIPTION END -->
				<!-- SINGLE-PRODUCT INFO TAB START -->
				<div class="row">
					<div class="col-sm-12">
						<div class="product-more-info-tab">
							<!-- Nav tabs -->
							<ul class="nav nav-tabs more-info-tab">
								<li class="active"><a href="#moreinfo" data-toggle="tab">Mô tả sản phẩm</a></li>
								<li><a href="#datasheet" data-toggle="tab">Hướng dẫn bảo quản</a></li>
							</ul>
							  <!-- Tab panes -->
							<div class="tab-content">
								<div class="tab-pane active" id="moreinfo">
									<div class="tab-description">
										<?php echo $product->detail; ?>

									</div>
								</div>
								<div class="tab-pane" id="datasheet">
									<div class="deta-sheet">
										<?php echo $product->how_to_use; ?>			
									</div>
								</div>
							</div>									
						</div>
					</div>
				</div>
				<!-- SINGLE-PRODUCT INFO TAB END -->
			</div>
			<!-- RIGHT SIDE BAR START -->
			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
				<!-- SINGLE SIDE BAR START -->
			<?php if(!empty($vieweds)): ?>
				<div class="single-product-right-sidebar">
					<h2 class="left-title">Sản phẩm vừa xem</h2>
					<ul>
					<?php foreach($vieweds as $viewed): ?>
						<li>
							<a href="<?php echo e(url('/product/'.$viewed->slug)); ?>"><img src="<?php echo e(config('image.image_url').'/products/'.$viewed->image_url().'_70x70.png'); ?>" alt="" /></a>
							<div class="r-sidebar-pro-content">
								<h5><a href="<?php echo e(url('/product/'.$viewed->slug)); ?>"><?php echo e($viewed->name); ?></a></h5><br/>
								<p><?php echo e(number_format($viewed->price,0,",",".")); ?> đ</p>
							</div>
						</li>
					<?php endforeach; ?>
					</ul>
				</div>	
			<?php endif; ?>
				<!-- SINGLE SIDE BAR END -->
				<!-- SINGLE SIDE BAR START -->						
				<!-- <div class="single-product-right-sidebar">
					<div class="slider-right zoom-img">
						<a href="#"><img class="img-responsive" src="" alt="sidebar left" /></a>
					</div>							
				</div> -->
			</div>
			<!-- SINGLE SIDE BAR END -->				
		</div>
	</div>
</section>
<!-- MAIN-CONTENT-SECTION END -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>