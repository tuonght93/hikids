<?php use Illuminate\Support\Str as Str; 
    use Illuminate\Support\Facades\Session as Session;
 ?>

<?php $__env->startSection('title'); ?>
    <?php if(empty($seo['title'])): ?>
        <title>Kết quả tìm kiếm1 | Happy Skin</title>
    <?php else: ?>
        <title><?php echo e($seo['title']); ?></title>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<!-- MAIN-CONTENT-SECTION START -->
<section class="main-content-section">
<div class="container">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<!-- BSTORE-BREADCRUMB START -->
			<div class="bstore-breadcrumb">
				<a href="<?php echo e(url('/')); ?>">Trang chủ</a>
				<span><i class="fa fa-caret-right	"></i></span>
				<span>Search</span>
			</div>
			<!-- BSTORE-BREADCRUMB END -->
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="right-all-product">
				<div class="product-category-title">
					<!-- PRODUCT-CATEGORY-TITLE START -->
					<h1>
						<span class="cat-name">Kết quả tìm kiếm : <?php echo e($keyword); ?></span>
						<span class="count-product">Sản phẩm tìm thấy : <?php echo e($products->count()); ?></span>
					</h1>
					<!-- PRODUCT-CATEGORY-TITLE END -->
				</div>
			</div>
			<!-- ALL GATEGORY-PRODUCT START -->
			<div class="new-product-area">					
				<div class="row">
					<div class="col-xs-12">
						<div class="row">
							<!-- HOME2-NEW-PRO-CAROUSEL START -->
							<!-- <div class="home2-new-pro-carousel"> -->
								<!-- NEW-PRODUCT SINGLE ITEM START -->
							<?php foreach($products as $item): ?>
							<div class="col-md-3">
								<div class="item">
									<div class="new-product">
										<div class="single-product-item">
											<div class="product-image">
												<a href="<?php echo e(url('/product/'.$item->slug)); ?>"><img src="<?php echo e(config('image.image_url').'/products/'.$item->image_url().'_400x300.png'); ?>" alt="<?php echo e($item->name); ?>" /></a>
												<span class="new-mark-box">new</span>
											</div>
											<div class="product-info">
												<h3><a href="<?php echo e(url('/product/'.$item->slug)); ?>" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a></h3>
												<div class="price-box">
													<span class="price"><?php echo e(number_format($item->price)); ?>  đ</span>
													<span class="old-price"><?php echo e(number_format($item->old_price)); ?> đ</span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<?php endforeach; ?>
								<!-- NEW-PRODUCT SINGLE ITEM END -->
							<!-- </div> -->
							<!-- HOME2-NEW-PRO-CAROUSEL END -->
						</div>
					</div>
				</div>
			</div>
			<!-- ALL GATEGORY-PRODUCT END -->
			<!-- PRODUCT-SHOOTING-RESULT START -->
			<?php if($products->count() < $products->total()): ?>
			<div class="product-shooting-result product-shooting-result-border">
				<div class="showing-item">
					<span>Hiển thị 1 - <?php echo e($products->count()); ?> của <?php echo e($products->total()); ?> sản phẩm</span>
				</div>
				<div class="showing-next-prev">
					<ul class="pagination-bar">
						<?php if($products->currentPage() != 1): ?>
						<li>
							<a href="<?php echo e(str_replace('/?','?',$products->url($products->currentPage() - 1))); ?>" ><i class="fa fa-chevron-left"></i>Previous</a>
						</li>
						<?php endif; ?>
						<?php for($i = 1; $i <= $products->lastPage(); $i++): ?>
						<li class="<?php echo e($products->currentPage() == $i ? 'active' : ''); ?>">
							<span><a class="pagi-num" href="<?php echo e(str_replace('/?','?',$products->url($i))); ?>"><?php echo e($i); ?></a></span>
						</li>
						<?php endfor; ?>
						<?php if($products->currentPage() != $products->lastPage()): ?>
						<li>
							<a href="<?php echo e(str_replace('/?','?',$products->url($products->currentPage() + 1 ))); ?>" >Next<i class="fa fa-chevron-right"></i></a>
						</li>
						<?php endif; ?>
					</ul>
				</div>
			</div>
			<?php endif; ?>
			<!-- PRODUCT-SHOOTING-RESULT END -->
		</div>
	</div>
</div>
</section>
<!-- MAIN-CONTENT-SECTION END -->
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('user.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>