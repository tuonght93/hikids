<!-- HEADER-BOTTOM-AREA START -->
<?php if(count($slides) > 0): ?> 
<section class="header-bottom-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<!-- MAIN-SLIDER-AREA START -->
				<div class="main-slider-area">
					<div class="slider-area">
						<div id="wrapper">
							<div class="slider-wrapper">
								<div id="mainSlider" class="nivoSlider">
									<?php foreach($slides as $slide): ?>
									<img src="<?php echo e(config('image.image_url').'/slides/'.$slide->thumbnail.'_1140x350.png'); ?>" alt="<?php echo e($slide->title); ?>" title="#<?php echo e($slide->slug); ?>"/>
									<?php endforeach; ?>
								</div>
								<?php foreach($slides as $slide): ?>
								<div id="<?php echo e($slide->slug); ?>" class="nivo-html-caption">
									<div class="slider-progress"></div>
									<div class="slider-cap-text slider-text2">
										<div class="d-table-cell">
											<h2 class="animated bounceInDown"><?php echo $slide->title; ?></h2>
											<p class="animated bounceInUp"><?php echo $slide->content; ?></p>	
											<a class="wow zoomInDown" data-wow-duration="1s" data-wow-delay="1s" href="<?php echo e(url($slide->link)); ?>">Đọc thêm <i class="fa fa-caret-right"></i></a>
										</div>
									</div>
								</div>
								<?php endforeach; ?>
							</div>
						</div>								
					</div>											
				</div>	
				<!-- MAIN-SLIDER-AREA END -->
			</div>						
		</div>
	</div>
</section>
<?php endif; ?>
<!-- HEADER-BOTTOM-AREA END -->