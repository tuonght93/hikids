<!-- HEADER-TOP START -->
<div class="header-top">
<?php $user = Auth::user(); ?>
	<div class="container">
		<div class="row">
			<!-- HEADER-LEFT-MENU START -->
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				<div class="header-left-menu">
					<?php if($user): ?>
					<div class="welcome-info">
						Xin chào <span><?php echo e(!empty($user->fullname) ? $user->fullname : $user->username); ?></span>
					</div>
					<?php endif; ?>
				</div>
			</div>
			<!-- HEADER-LEFT-MENU END -->
			<!-- HEADER-RIGHT-MENU START -->
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				<div class="header-right-menu">
					<nav>
						<ul class="list-inline">
							<li><a href="<?php echo e(url('/checkout')); ?>">Thanh toán</a></li>
							<li><a href="#">Tài khoản</a></li>
							<li><a href="<?php echo e(url('/cart')); ?>">Giỏ hàng</a></li>
							<?php if($user): ?>
								<li><a href="<?php echo e(url('/user/logout')); ?>">Đăng xuất</a></li>
							<?php else: ?>
								<li><a href="<?php echo e(url('/user/login')); ?>">Đăng nhập</a></li>
							<?php endif; ?>
						</ul>									
					</nav>
				</div>
			</div>
			<!-- HEADER-RIGHT-MENU END -->
		</div>
	</div>
</div>
<!-- HEADER-TOP END -->
<!-- HEADER-MIDDLE START -->
<section class="header-middle">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<!-- LOGO START -->
				<div class="logo">
					<a href="index.html"><img src="" alt="bstore logo" /></a>
				</div>
				<!-- LOGO END -->
				<!-- HEADER-RIGHT-CALLUS START -->
				<div class="header-right-callus">
					<h3>Gọi chúng tôi</h3>
					<span>0911-331-616</span>
				</div>
				<!-- HEADER-RIGHT-CALLUS END -->
				<!-- CATEGORYS-PRODUCT-SEARCH START -->
				<div class="categorys-product-search">
					<form action="/search" method="get" class="search-form-cat">
						<div class="search-product form-group">
							<input style="width: 478px;" type="text" class="form-control search-form" name="keyword" id="txtkey" placeholder="Bố mẹ tìm gì cho bé hôm nay? " />
							<button class="search-button" type="submit">
								<i class="fa fa-search"></i>
							</button>							 
						</div>
					</form>
				</div>
				<!-- CATEGORYS-PRODUCT-SEARCH END -->
			</div>
		</div>
	</div>
</section>
<!-- HEADER-MIDDLE END -->
