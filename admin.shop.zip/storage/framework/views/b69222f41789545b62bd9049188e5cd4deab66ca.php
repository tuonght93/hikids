<?php use Illuminate\Support\Str as Str; 
    use Illuminate\Support\Facades\Session as Session;
 ?>


<?php $__env->startSection('title'); ?>
   <title> Admin</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
   <link rel="stylesheet" type="text/css" href="/css/dataTables.bootstrap.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="page-head">
      <h2>Thống kê hệ thống</h2>      
    </div>
     <div class="cl-mcont">        
          	
    </div>    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="/js/dataTables.bootstrap.min.js" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptend'); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('back.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>