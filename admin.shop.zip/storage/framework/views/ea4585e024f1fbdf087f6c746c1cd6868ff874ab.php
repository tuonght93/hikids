<?php foreach($sizes as $size): ?>
	<option value="<?php echo e($size->size_id); ?>"><?php echo e($size->size->title); ?></option>
<?php endforeach; ?>