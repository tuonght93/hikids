<option value="">Chọn Quận / Huyện</option>
<?php foreach($districts as $district): ?>
	<option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
<?php endforeach; ?>