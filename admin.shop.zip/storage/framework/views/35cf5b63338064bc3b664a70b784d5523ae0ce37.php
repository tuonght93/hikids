<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->

  <head>
    <meta charset="utf-8"/>
    <?php echo $__env->yieldContent('title'); ?>

    <?php echo $__env->make('user/inc/meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldContent('head'); ?>
    <!--
    <?php echo HTML::style('http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'); ?>

    <?php echo HTML::style('http://fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic'); ?>

    -->
  </head>

  <body class="index-2">

      <?php echo $__env->make('user/inc/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->make('user/inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->yieldContent('main'); ?>

      <?php echo $__env->make('user/inc/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->make('user/inc/script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->yieldContent('scripts'); ?>

  </body>
</html>