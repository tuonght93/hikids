<?php use Illuminate\Support\Str as Str; 
    use Illuminate\Support\Facades\Session as Session;
 ?>


<?php $__env->startSection('title'); ?>
   <title>Login | HappySkin Admin</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div id="cl-wrapper" class="error-container">
      <div class="page-error">
        <h1 class="number text-center">404</h1>
        <h2 class="description text-center">Sorry, but this page doesn't exists!</h2>
        <h3 class="text-center">Would you like to go <a href="<?php echo e(url('/manage')); ?>">home</a>?</h3>
      </div>
       <div class="text-center out-links"><a href="#">© 2015 Malaria</a></div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="/js/validation/parsley.min.js" type="text/javascript"></script>
    <script src="/js/validation/dateiso.js" type="text/javascript"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.none_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>