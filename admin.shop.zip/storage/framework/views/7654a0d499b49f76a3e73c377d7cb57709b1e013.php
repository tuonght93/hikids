<?php use Illuminate\Support\Str as Str; 
    use Illuminate\Support\Facades\Session as Session;
 ?>


<?php $__env->startSection('title'); ?>
   <title>Products | HappySkin Admin</title>
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <link href="/css/summernote.css" rel="stylesheet"> 
  <link href="/css/element/blue.css" rel="stylesheet">
  <link href="/css/model_component.css" rel="stylesheet">
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
      <div class="page-head">
        <h2>Người dùng hệ thống </h2>
        <ol class="breadcrumb">
          <li><a href="<?php echo e(url('/manage/user')); ?>">Người dùng</a></li>
          <li><?php echo e(empty($user->id) ? 'Thêm mới' : 'Sửa'); ?></li>
        </ol>
      </div>
      <div class="cl-mcont">
          <div class="row">
            <div class="col-md-12">            
            <?php echo Form::open(['url' => '/manage/user/'.$user->id, 'method' => empty($user->id) ? 'POST' : 'PUT', 'role' => 'form', 'files' => 'true', 'class' => 'form-horizontal group-border-dashed', 'style' => 'border-radius: 0px;', 'id' => 'form_user']); ?> 
              <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">

              <div class="block-flat">
                <div class="header">
                  <h3>Thông tin</h3>
                </div>
                <div class="content">

                  <?php echo $__env->make('errors/error_validation', ['errors' => $errors], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                  <div class="form-group">
                    <label class="col-sm-3 control-label">Tài khoản</label>
                    <div class="col-sm-6">

                      <?php echo Form::text('username', $user->username, array('placeholder' => 'Tên tài khoản', 'class' => 'form-control')); ?>


                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-6">
                      <?php echo Form::text('email', $user->email, array('placeholder' => 'Email', 'class' => 'form-control')); ?>

                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-3 control-label">Mật khẩu</label>
                    <div class="col-sm-6">
                      <?php echo Form::password('password', array('class' => 'form-control', 'id' => 'password', 'title' => 'Mật khẩu')); ?>

                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-3 control-label">Nhập lại mật khẩu</label>
                    <div class="col-sm-6">
                      <?php echo Form::password('password_confirmation', array('class' => 'form-control', 'id' => 'password_confirm', 'title' => 'Mật khẩu')); ?>                    
                    </div>
                  </div>

                  <div class="form-group" id="form_select_role">
                    <label class="col-sm-3 control-label">Quyền truy cập</label>
                    <div class="col-sm-6">
                       <?php 
                            $data_roles = array();
                        ?>
                        <?php foreach($roles as $role): ?>
                          <?php
                            $data_roles[''.$role->type] = $role->name;
                          ?>             
                        <?php endforeach; ?>
                        <?php echo Form::select('role', $data_roles,$user->role_id?$user->role_id:3, array('id' => 'role', 'class' => 'form-control')); ?>

                    </div>
                  </div>

                  <div class="form-group" id="form_select_ticketroom">
                    <label class="col-sm-3 control-label">Tỉnh/Thành phố</label>
                    <div class="col-sm-6">
                       <?php 
                            $data_cities[] = "-- Thành phố --";
                        ?>
                        <?php foreach($cities as $city): ?>
                          <?php
                            $data_cities[''.$city->slug] = $city->name;
                          ?>             
                        <?php endforeach; ?>
                        <?php echo Form::select('city', $data_cities,$user->city , array('id' => 'role', 'class' => 'form-control')); ?>

                    </div>
                  </div>                  

                </div>
              </div>  

              <div class="row block-flat">
                <div class="col-sm-offset-2 col-sm-10">
                    <a href="<?php echo e(url('/manage/user')); ?>" class="btn btn-default">Trở lại</a>
                    <button id="form_submit" type="submit" class="btn btn-primary wizard-next">Lưu thông tin</button>
                </div>
              </div>

              </form>            
            </div>
          </div>
      </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script type="text/javascript" src="/js/summernote.min.js"></script>
  <script type="text/javascript" src="/js/icheck.min.js"></script>
  
  
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptend'); ?>
    <script type="text/javascript">
      $(document).ready(function(){
        $('#role').change(function(){
          if ($(this).val() == '2') {
            $('#form_select_ticketroom').css('display', 'block');
          } else {
            $('#form_select_ticketroom').css('display', 'none');
          }
        });

        if ($('#role').val() == '2') {
          $('#form_select_ticketroom').css('display', 'block');
        } else {
          $('#form_select_ticketroom').css('display', 'none');
        }
      });
            
    </script>  
<?php $__env->stopSection(); ?>




<?php echo $__env->make('back.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>