<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Moloquent;
  class Color extends Model {

    protected $collection = 'colors';

    // public function users() 
    // {
    //   return $this->hasMany('App\Models\User');
    // }

}