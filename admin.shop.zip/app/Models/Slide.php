<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Moloquent;
  class Slide extends Model {

    protected $table = 'slides';
    //public $timestamps = false;
    //protected $primaryKey = '_id';
    // protected $connection = 'mongodb';

    
  }
?>