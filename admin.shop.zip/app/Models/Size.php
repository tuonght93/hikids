<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Moloquent;
  class Size extends Model {

    protected $collection = 'sizes';

    // public function users() 
    // {
    //   return $this->hasMany('App\Models\User');
    // }

}