<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Moloquent;
  class Page extends Model {

    protected $collection = 'pages';

    // public function users() 
    // {
    //   return $this->hasMany('App\Models\User');
    // }

}